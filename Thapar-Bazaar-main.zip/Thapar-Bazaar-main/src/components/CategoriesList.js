let Categories = ['Bikes', 'Mobiles', 'Cloth', 'Plots', 'Sale', 'Rent', 'To Let', 'Laptops', 'Electronics']

export default Categories;